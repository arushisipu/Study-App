package com.example.uiaa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class phy_sol : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phy_sol)
        val button = findViewById<Button>(R.id.viewPDF1)
        button.setOnClickListener {
            val intent = Intent(applicationContext, WebActivity::class.java)
            intent.putExtra(
                "pdf_url",
                "https://arushi0819.000webhostapp.com/Physics/Solutions/Chapter-1-electric-charges-and-fields.pdf"
            )
            startActivity(intent)
        }
    }
}