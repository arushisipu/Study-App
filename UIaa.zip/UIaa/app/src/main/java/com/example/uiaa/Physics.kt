package com.example.uiaa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_physics.*

class Physics : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_physics)

        book1.setOnClickListener{
            startActivity(Intent(this@Physics,phy_tb::class.java))
        }
        book2.setOnClickListener{
            startActivity(Intent(this@Physics,phy_sol::class.java))
        }
        book3.setOnClickListener{
            startActivity(Intent(this@Physics,phy_notes::class.java))
        }
        book4.setOnClickListener{
            startActivity(Intent(this@Physics,phy_mm::class.java))
        }
        book5.setOnClickListener{
            startActivity(Intent(this@Physics,phy_pap::class.java))
        }
    }
}