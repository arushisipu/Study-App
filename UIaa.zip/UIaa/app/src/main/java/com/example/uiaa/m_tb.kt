package com.example.uiaa

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_maths.*
import kotlinx.android.synthetic.main.activity_mtb.*
import kotlinx.android.synthetic.main.activity_mtb.*

class m_tb : AppCompatActivity() {

    var mydownloadid : Long=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mtb)
        viewPDF1.setOnClickListener{
            startActivity(Intent(this@m_tb,m_tb::class.java))
        }
        viewPDF1.setOnClickListener{
            var request= DownloadManager.Request(
                Uri.parse(" /public_html/Maths/Book/NCERT Book Mathematics Part I Class 12.pdf"))
                .setTitle("Maths Textbook Part1")
                .setDescription("Maths Textbook Part1 Downloading")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setAllowedOverMetered(true)

            var dm =getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            mydownloadid = dm.enqueue(request)
        }
        var br = object: BroadcastReceiver(){
            override fun onReceive(p0: Context?, p1: Intent?) {
                var id:Long? = p1?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,-1)
                if(id==mydownloadid)
                {
                    Toast.makeText(applicationContext,"Maths Textbook Part1 Download Completed",
                        Toast.LENGTH_LONG).show()
                }
            }

        }
        registerReceiver(br, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
    }
}

