package com.example.uiaa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class m_notes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mnotes)
    }
}