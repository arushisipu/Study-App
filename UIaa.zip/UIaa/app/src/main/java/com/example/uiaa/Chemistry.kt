package com.example.uiaa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_chemistry.*
import kotlinx.android.synthetic.main.activity_physics.*

class Chemistry : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chemistry)
        book11.setOnClickListener{
            startActivity(Intent(this@Chemistry,Chem_tb::class.java))
        }
        book12.setOnClickListener{
            startActivity(Intent(this@Chemistry,chem_sol::class.java))
        }
        book13.setOnClickListener{
            startActivity(Intent(this@Chemistry,chem_mm::class.java))
        }
        book14.setOnClickListener{
            startActivity(Intent(this@Chemistry,chem_notes::class.java))
        }
        book15.setOnClickListener{
            startActivity(Intent(this@Chemistry,chem_pap::class.java))
        }
    }
}