package com.example.uiaa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class WebActivity1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web1)
        val url = intent.getStringExtra("pdf_url")
        val webView = findViewById<WebView>(R.id.web)
        webView.webViewClient = WebViewClient()
        webView.loadUrl("https://docs.google.com/gview?embedded=true&url=$url")
    }
}