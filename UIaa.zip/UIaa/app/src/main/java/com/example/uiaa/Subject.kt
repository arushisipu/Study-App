package com.example.uiaa

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_chemistry.*
import kotlinx.android.synthetic.main.activity_maths.*
import kotlinx.android.synthetic.main.activity_physics.*
import kotlinx.android.synthetic.main.activity_subject.*

class Subject : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subject)
    onClickListener();
        onClickListener1();
        onClickListener2();
    }

        fun onClickListener() {
            phy.setOnClickListener {
                startActivity(Intent(this@Subject, Physics::class.java))
            }
        }
            fun onClickListener1() {
                chem.setOnClickListener {
                    startActivity(Intent(this@Subject, Chemistry::class.java))
                }
            }
                fun onClickListener2() {
                    math.setOnClickListener {
                        startActivity(Intent(this@Subject, Maths::class.java))
                    }}


}