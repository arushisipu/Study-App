package com.example.uiaa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_maths.*
import kotlinx.android.synthetic.main.activity_physics.*

class Maths : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maths)
        book6.setOnClickListener{
            startActivity(Intent(this@Maths,m_tb::class.java))
        }
        book7.setOnClickListener{
            startActivity(Intent(this@Maths,m_sol::class.java))
        }
        book8.setOnClickListener{
            startActivity(Intent(this@Maths,m_notes::class.java))
        }
        book9.setOnClickListener{
            startActivity(Intent(this@Maths,m_mm::class.java))
        }
        book10.setOnClickListener{
            startActivity(Intent(this@Maths,m_pap::class.java))
        }
    }
}